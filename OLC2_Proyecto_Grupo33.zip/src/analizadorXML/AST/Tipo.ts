export enum Tipo {
    STRING,
    INT,
    DOUBLE,
    BOOL,
    VOID,
    STRUCT,
    NULL,
    ATRIBUTO,
    ARRAY
}